# ДЗ №53 — Список TODO

## Запуск на Windows
1. Откройте терминал в папке `source`.
2. Установите Django: `python -m pip install -r ../requirements.txt`
3. Примените миграции: `python manage.py migrate`
4. (Необязательно) загрузите примеры: `python manage.py loaddata tasks/fixtures/tasks.json`
5. Запустите: `python manage.py runserver`
6. Откройте http://127.0.0.1:8000/

Проверка: `python manage.py check`, `python manage.py makemigrations --check --dry-run`, `python manage.py test`.

Это восстановленная копия по условию ДЗ №53, а не исходная папка с историей Git и старой базой данных.
